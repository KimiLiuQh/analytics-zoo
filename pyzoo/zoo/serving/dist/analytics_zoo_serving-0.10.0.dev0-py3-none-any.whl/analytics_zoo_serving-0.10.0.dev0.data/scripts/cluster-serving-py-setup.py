#!python

from zoo.serving.server import ClusterServing
serving = ClusterServing()

print("Cluster Serving has been properly set up.")